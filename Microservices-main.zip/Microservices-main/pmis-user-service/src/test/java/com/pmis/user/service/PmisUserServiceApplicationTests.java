package com.pmis.user.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PmisUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

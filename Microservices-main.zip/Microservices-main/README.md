# Microservices
This repository will contain the Java developed system, based on Microservice architecture.

com-order-service:
               This service is managing orders like placing, getting or updating orders.
               
com-product-service:
               This service is managing products like adding, getting or updating products.
               
pmis-user-service:
               This service is managing users like adding, getting or updating users.

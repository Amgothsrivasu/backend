package com.product.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PmisProductServiceApplication {
	public static void main(String[] args) {
		SpringApplication.run(PmisProductServiceApplication.class, args);
	}
}

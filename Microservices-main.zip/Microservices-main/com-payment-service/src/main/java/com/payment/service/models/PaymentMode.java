package com.payment.service.models;

public enum PaymentMode {
    CASH,
    PAYPAL,
    DEBIT_CARD,
    CREDIT_CARD;
}

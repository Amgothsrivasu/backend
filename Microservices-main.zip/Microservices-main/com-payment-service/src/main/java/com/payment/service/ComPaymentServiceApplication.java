package com.payment.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComPaymentServiceApplication { public static void main(String[] args) {
		SpringApplication.run(ComPaymentServiceApplication.class, args);
	}
}

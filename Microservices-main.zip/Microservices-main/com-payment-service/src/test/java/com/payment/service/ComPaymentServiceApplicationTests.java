package com.payment.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComPaymentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.order.service.models;

public enum PaymentMode {
    CASH,
    DEBIT_CARD,
    CREDIT_CARD;
}
